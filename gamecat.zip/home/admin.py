"""Registering models"""
from django.contrib import admin
from .models import ClicksUser

# Register your models here.
admin.site.register(ClicksUser)
